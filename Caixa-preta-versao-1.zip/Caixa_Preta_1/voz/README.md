# Sistema de Áudio - Caixa Preta

Este diretório contém os arquivos de texto para geração de áudio do projeto Caixa Preta, organizados em duas categorias distintas, além do sistema de áudio implementado.

## 📁 Estrutura

```
voz/
├── narracao/           # Textos para experiência imersiva
├── acessibilidade/     # Textos completos para acessibilidade
└── README.md          # Este arquivo
```

## 🎭 `/narracao/` - Experiência Imersiva

**Propósito:** Textos poéticos e concisos para narração durante a experiência.

**Características:**
- Textos mais curtos e impactantes
- Linguagem poética e fragmentada
- Foco na atmosfera e emoção
- Ideal para narração em tempo real
- Formato: `[página]_narracao.txt`

**Uso:** Botões "🔊 Ouvir narração" nas páginas principais.

## ♿ `/acessibilidade/` - Acessibilidade Completa

**Propósito:** Textos completos e detalhados para pessoas com deficiência visual.

**Características:**
- Conteúdo completo e detalhado
- Inclui todas as interações e opções
- Linguagem clara e descritiva
- Ideal para leitura completa ou TTS
- Formato: `[página]_acessibilidade.txt`

**Uso:** Conversão completa para áudio ou leitura por screen readers.

## 🎯 Diferenças Principais

| Aspecto | Narração | Acessibilidade |
|---------|----------|----------------|
| **Tamanho** | Conciso | Completo |
| **Estilo** | Poético | Descritivo |
| **Foco** | Atmosfera | Informação |
| **Uso** | Experiência | Acessibilidade |
| **Público** | Todos | PcD visual |

## 🔧 Implementação

### Scripts de Narração
- Usam textos da pasta `/narracao/`
- Botões "🔊 Ouvir narração" nas páginas
- Texto embutido em JSON

### Scripts de Chat
- Botões "🔊 Ouvir" em mensagens da IA
- Funcionam dinamicamente
- Usam Web Speech API

## 📱 Compatibilidade

- ✅ Web Speech API (Chrome, Firefox, Safari, Edge)
- ✅ Screen Readers
- ✅ Dispositivos móveis
- ✅ Acessibilidade por teclado
- ✅ ARIA labels

## 🎨 Personalização

Para ajustar a voz, modifique nos scripts:
- `LANG`: Idioma (pt-BR)
- `RATE`: Velocidade (0.1-10)
- `PITCH`: Tom (0-2)

## 📝 Manutenção

- **Narração:** Atualize textos poéticos para manter atmosfera
- **Acessibilidade:** Mantenha conteúdo completo e descritivo
- **Scripts:** Teste em diferentes navegadores
- **ARIA:** Verifique labels de acessibilidade

## 🎵 Sistema de Áudio Implementado

### Arquivos Principais
- `audio-manager.js` - Sistema centralizado de gerenciamento de áudio
- `audio-button.js` - Controle global de áudio e navegação

### Funcionalidades
- **Controle Global**: Botão único para ativar/desativar áudio em todas as páginas
- **Interrupção Automática**: Sons param automaticamente ao trocar de página
- **Múltiplos Formatos**: Suporte a HTML Audio, Web Audio API e Speech Synthesis
- **Persistência**: Preferências salvas no localStorage
- **Feedback Sonoro**: Sons específicos para cada interação

### Tipos de Áudio Suportados
- **HTML Audio**: Arquivos MP3, WAV, OGG
- **Web Audio API**: Sons gerados programaticamente
- **Speech Synthesis**: Texto para voz com Web Speech API

### Arquivos de Som Incluídos
- `alarm-siren-sound-effect-type-01-294194.mp3` - Som de alarme
- `button-press-2-386176.mp3` - Som de clique
- `computer-processing-sound-effect-01-122131.mp3` - Som de processamento
- `error-beep-2-296492.mp3` - Som de erro
- `funny-sound-effect-for-quotjack-in-the-boxquot-sound-ver1-110923.mp3` - Som do quiz
- `gear-spinning-loop-6981.mp3` - Som de engrenagem
- `metal-drawer-with-objects-inside-105838.mp3` - Som de gaveta
- `snd_tacataca3-412245.mp3` - Som de processamento
- `sonido-correcto-331225.mp3` - Som de resposta correta
- `water-splash-02-352021.mp3` - Som de água

### Funcionalidades por Página

#### 1-index.html
- Som de hover na caixa 3D
- Som de clique ao iniciar jornada

#### 2-chat.html
- Narração automática da primeira mensagem
- Botões "🔊 Ouvir" em mensagens da IA
- Som de confirmação ao responder

#### 3-transition.html
- Som de alarme durante transição
- Som de processamento

#### 4-primeira-camada.html
- Som de processamento durante tokenização
- Botões "🔊 Ouvir" em mensagens da IA
- Som de confirmação

#### 5-segunda-camada.html
- Som de água ao clicar em hotspots
- Som de bateria, gaveta e engrenagem
- Botões "🔊 Ouvir" em mensagens da IA

#### 6-terceira-camada.html
- Som de clique em dropdown
- Som específico para cada resposta do quiz
- Som de clique em links da timeline
- Botão "🔊 Ouvir" reposicionado

#### 7-quarta-camada.html
- Som de erro no início
- Narração automática da primeira mensagem
- Botões "🔊 Ouvir" em mensagens da IA

#### 8-prefechamento.html
- Botões "🔊 Ouvir" em mensagens da IA

#### 9-vibe-coding-desprogramativo.html
- Botões "🔊 Ouvir" em mensagens da IA

## 🎛️ Controles de Áudio

### Botão Global
- **Localização**: Canto superior direito de todas as páginas
- **Função**: Ativa/desativa áudio globalmente
- **Persistência**: Estado salvo no localStorage
- **Visual**: Ícone de alto-falante com estado visual

### Interrupção Automática
- **Navegação**: Sons param ao trocar de página
- **Múltiplos Formatos**: HTML Audio, Web Audio API, Speech Synthesis
- **Limpeza**: Elementos de áudio são pausados e resetados

### Narração Automática
- **Primeira Mensagem**: Lida automaticamente se áudio estiver ativado
- **Botões Individuais**: Cada mensagem pode ser lida separadamente
- **Limpeza**: Speech Synthesis é cancelado ao navegar

## 🔧 Implementação Técnica

### audio-manager.js
```javascript
// Funções principais
- stopAllAudio() - Para todos os sons
- trackAudioElement() - Monitora elementos HTML Audio
- trackAudioContext() - Monitora contextos Web Audio API
- playAudioFile() - Reproduz arquivos de áudio
- playProcessingSound() - Som de processamento
- playHoverSound() - Som de hover
- playConfirmationSound() - Som de confirmação
- playErrorSound() - Som de erro
- playAccessSound() - Som de acesso
```

### audio-button.js
```javascript
// Funcionalidades
- Controle global de áudio
- Persistência no localStorage
- Interrupção ao navegar
- Interceptação de cliques em links
- Event listeners para beforeunload e pagehide
```

## 🎯 Configurações

### Web Speech API
- **Idioma**: pt-BR (português brasileiro)
- **Velocidade**: 1.0 (normal)
- **Tom**: 1.0 (normal)
- **Limpeza**: Cancelamento automático ao navegar

### HTML Audio
- **Volume**: Variável por tipo de som
- **Controles**: Pause, currentTime reset
- **Tracking**: Monitoramento de elementos ativos

### Web Audio API
- **Contextos**: Criação e suspensão automática
- **Tracking**: Monitoramento de contextos ativos
- **Limpeza**: Suspensão automática ao navegar

## 📱 Compatibilidade de Navegadores

### Web Speech API
- ✅ Chrome 33+
- ✅ Firefox 49+
- ✅ Safari 7+
- ✅ Edge 79+

### HTML Audio
- ✅ Todos os navegadores modernos
- ✅ Suporte a MP3, WAV, OGG

### Web Audio API
- ✅ Chrome 14+
- ✅ Firefox 25+
- ✅ Safari 6+
- ✅ Edge 12+

## 🎨 Personalização de Sons

### Volume por Tipo
- **Cliques**: 0.4 (40%)
- **Hover**: 0.3 (30%)
- **Erros**: 0.6 (60%)
- **Confirmações**: 0.5 (50%)
- **Processamento**: 0.4 (40%)

### Tempo de Reprodução
- **Sons Curtos**: 0.5-2 segundos
- **Sons de Ambiente**: 3-5 segundos
- **Narração**: Variável conforme texto

## 🔍 Debugging

### Console Logs
- Erros de reprodução de áudio
- Status de ativação/desativação
- Informações de tracking

### Verificação de Estado
- `isAudioEnabled()` - Verifica se áudio está ativado
- `activeAudioElements` - Lista elementos HTML Audio ativos
- `activeAudioContexts` - Lista contextos Web Audio API ativos

## 📚 Recursos Adicionais

### Documentação
- **README.md** - Documentação principal do projeto
- **PROMPTS.md** - Histórico de prompts utilizados

### Arquivos de Texto
- **narracao/** - Textos para narração
- **acessibilidade/** - Textos para acessibilidade

### Suporte
- **Web Speech API**: [MDN Documentation](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API)
- **Web Audio API**: [MDN Documentation](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API)
- **HTML Audio**: [MDN Documentation](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/audio)

---

*Sistema de áudio implementado para proporcionar experiência imersiva e acessível em todas as páginas do projeto Caixa Preta.*